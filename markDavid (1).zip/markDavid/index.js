const Discord = require('discord.js');
const bot = new Discord.Client();
const fs = require('fs');
const config = require('./storage/config.json');
const prefix = config.prefix;

bot.commands = new Discord.Collection();

// OnMember Join
bot.on('guildMemberAdd', member => {
  console.log(`User: (${member.user.username}) joined the server.`);
});

// OnMember Leave
bot.on('guildMemberRemove', member => {
  console.log(`User: (${member.user.username}) left the server.`);

});

// Bot isEnabled
bot.on('ready', async () => {

  console.log(`${bot.user.username} Bot is enabling...`);

  try {

    let link = await bot.generateInvite(["ADMINISTRATOR"]);

    // Command Handler
    const commandFiles = fs.readdirSync("./commands");
    commandFiles.forEach((file) => {
      const command = require(`./commands/${file}`);
      bot.commands.set(command.name, command);

      console.log(`Module: (${file}) loaded!`)
    });

    console.log("Ready");

  } catch(e) {

    console.log(e.stack);
  }
});

// Listener
bot.on("message", async(message) => {

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift();

  if (message.author.bot && message.content.startsWith(prefix)) return;
  if (!message.content.startsWith(prefix)) return;
  if (message.channel.type != 'text') return;
  let cmd = bot.commands.get(command.toLowerCase());
  if (cmd) cmd.execute(message,args);
});

bot.login(config.token);

const Discord = require('discord.js');
const config = require('../storage/config.json');

// -remove @<user>
module.exports = {
  name: "remove",
  execute: (message, args) => {

    if(!message.member.roles.some(r=>["President", "Management", "Sales Representative"].includes(r.name))) {

      console.log(`User: (${message.author.username}) was denied permission to (-remove).`);
      return;
    }

    if (!message.channel.name.includes(`ticket-`))  {
      return;
    }

    if (!message.mentions.members.first()) {
      message.delete();
      message.reply(`Please @ a valid user.`)
      .then(msg => {
        msg.delete(10000)
      })
      .catch();
      return;
    }

    if (args[1]) {
      message.delete();
      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription(`:x: **Usage** \`-remove <@user>\``))
      .then(msg => {
        msg.delete(10000)
      })
      .catch();
      return;
    }

    let User = message.mentions.members.first();

    if (message.author.username === User.user.username) {
      message.delete();
      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription('**Usage** `-leave`'))
      .then(msg => {
        msg.delete(5000)
      })
      .catch();
      return;
    }

    if(User.highestRole.position >= message.member.highestRole.position) {
      message.delete();
      message.channel.send(new Discord.RichEmbed().setColor("#FF9090").setDescription(`:x: **Insufficient Permission**`))
      .then(msg => {
        msg.delete(5000)
      })
      .catch();
      return;
    }

      message.channel.overwritePermissions(User, {
        VIEW_CHANNEL: false,
        SEND_MESSAGES: false
      })
      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription(`:white_check_mark: **Removed ${User} from the ticket**`));
      console.log(`User: (${message.author.username}) removed (${User.user.username}) from (${message.channel.name}).`);
  }
}

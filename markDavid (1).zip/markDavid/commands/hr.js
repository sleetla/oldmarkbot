const Discord = require('discord.js');
const ms = require('ms');
const math = require('mathjs');
const rn = require('random-number');
const config = require('../storage/config.json');

// -hr
module.exports = {
  name: "hr",
  execute: (message, args) => {

    var options = {
      min: 100002,
      max: 800002,
      integer: true
    }

    if (message.mentions.members.first()) {
      return;
    }

    if (args[0]) {
      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription('**Usage** `-hr`'));
      return;
    }

    if (!args[0]) {


      let tcn = Math.floor(Math.random() + rn(options)) + 1; // Ticket Number

      message.guild.createChannel(`hr-${tcn}`, 'text').then(c => {
        c.setParent('485272311830806528');
        c.overwritePermissions(c.guild.defaultRole, {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false
        })
        c.overwritePermissions(message.member, {
          VIEW_CHANNEL: true,
          SEND_MESSAGES: true
        })
        c.overwritePermissions(message.guild.roles.find("name", "Management"), {
          VIEW_CHANNEL: true,
          SEND_MESSAGES: true
        })

        console.log(`User: (${message.author.username}) created a (hr) ticket.`);

        return;
      })
    }
  }
}

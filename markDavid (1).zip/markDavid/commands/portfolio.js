const Discord = require('discord.js');
const config = require('../storage/config.json');
const fs = require('fs');

// -portfolio <@user>
module.exports = {
    name: "portfolio",
    execute: (message, args) => {

      pf = require('../storage/portfolios.json');

      if(!args[0]) {

        let aport = pf [message.author.username];
        if (!aport) return;
        let aportfolio = pf [message.author.username].port;
        if (!aportfolio) return;

        let embed = new Discord.RichEmbed()
        .setAuthor(`Athena Portfolios`, config.logo)
        .setDescription(`　　\n\n[${message.author.username}'s Portfolio](${aportfolio})`)
        .setThumbnail(message.author.avatarURL)
        .setColor(config.color);
        message.channel.send(embed);

        console.log(`User: (${message.author.username}) checked their portfolio.`);
        return;

      }

      let user = message.mentions.members.first();

      if(!user) return message.channel.send(new Discord.RichEmbed().setDescription('**Usage** `-portfolio <@user>`').setColor(config.color));

      let uport = pf [user.user.username];
      if (!uport) return;
      let portfolio = pf [user.user.username].port;
      if (!portfolio) return;


      let embed = new Discord.RichEmbed()
      .setAuthor(`Athena Portfolios`, config.logo)
      .setDescription(`　　\n\n[${user.user.username}'s Portfolio](${portfolio})`)
      .setThumbnail(user.user.avatarURL)
      .setColor(config.color);
      message.channel.send(embed);

      console.log(`User: (${message.author.username}) checked (${user.user.username})'s portfolio.`);
    }
  }

const Discord = require('discord.js');
const config = require('../storage/config.json');
const bot = new Discord.Client();

// -help
module.exports = {
    name: "help",
    execute: (message, args) => {

      let embed = new Discord.RichEmbed()
      .setAuthor(`markDavid Group Help Manual`, config.logo)
      .setDescription(`_markDavid Group - Version 1.0.0b17 - Page 1 of 1_`)
      .addField(`__**TicketCommands:**__`, `**-new** - Create a ticket.\n**-close** - Close a ticket.\n**-leave** - Leave a ticket.\n**-add <@user>** - Add a user to a ticket.`)
      .addField(`__**OtherCommands:**__`, `**-hr** - Create a ticket with management.\n**-cut <#>** - Calculate a cut from a commission.\n**-portfolio <@user>** - Check out a freelancers portfolio.`)
      .setTimestamp()
      .setFooter("© Athena Services")
      .setColor(config.color);

      message.channel.send(embed);
      console.log(`User: (${message.author.username}) pinged the help command.`);
    }
  }

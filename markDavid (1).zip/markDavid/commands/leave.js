const Discord = require('discord.js');
const config = require('../storage/config.json');
const bot = new Discord.Client();

// -leave
module.exports = {
    name: "leave",
    execute: (message, args) => {

      if (args[0]) return;

      if (!message.channel.name.includes(`ticket-`))  {
        return;
      }

      message.channel.overwritePermissions(message.author, {
        VIEW_CHANNEL: false,
        SEND_MESSAGES: false
      })

      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription(`:bangbang:**${message.author} left the ticket**`));

      console.log(`User: (${message.author.username}) left (${message.channel.name})`);
      return;
    }
  }

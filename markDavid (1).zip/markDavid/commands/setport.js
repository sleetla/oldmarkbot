const Discord = require('discord.js');
const config = require('../storage/config.json');
const fs = require('fs');

// -setport <portfolio>
module.exports = {
    name: "setport",
    execute: (message, args) => {

      if(!message.member.roles.some(r=>["Freelancer"].includes(r.name))) {
        console.log(`User: (${message.author.username}) was denied permission to (-setup).`);

        return;
      }

      pf = require('../storage/portfolios.json');

      if(!args[0]) return message.channel.send(new Discord.RichEmbed().setDescription('**Usage** `-setport <link-portfolio>`').setColor(config.color));

      if (message.content.includes('https://www.pornhub.com/')) return message.delete();

      if (!message.content.includes('https://')) return message.channel.send(new Discord.RichEmbed().setDescription(':x: **Not a proper link, please include __https://__**').setColor("#FF9090"));

      pf [message.author.username] = {
        port: args[0]
      }

      let embed = new Discord.RichEmbed()
      .setDescription(":white_check_mark:  **Portfolio Set**")
      .setColor(config.color);
      message.channel.send(embed);
      fs.writeFile("./storage/portfolios.json", JSON.stringify (pf, null, 4));

      console.log(`User: (${message.author.username}) closed (${message.channel.name}).`);
    }
  }

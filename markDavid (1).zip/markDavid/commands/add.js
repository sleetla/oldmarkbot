const Discord = require('discord.js');
const config = require('../storage/config.json');

// -add @<userid>
module.exports = {
  name: "add",
  execute: (message, args) => {

    let mUser = message.mentions.members.first();

    if(!mUser) return message.channel.send(new Discord.RichEmbed().setDescription('**Usage** `-add <@user>`').setColor(config.color));

    if(message.author.username === mUser.user.username) return;


      const ch = message.guild.channels.find('name', `${message.channel.name}`);

        ch.overwritePermissions(mUser, {
          VIEW_CHANNEL: true,
          SEND_MESSAGES: true
        })
        ch.send(new Discord.RichEmbed().setColor(config.color).setDescription(`:white_check_mark: **Added ${mUser} to the ticket**`));

        console.log(`User: (${message.author.username}) added a user to (${message.channel.name}).`);
    }
  }

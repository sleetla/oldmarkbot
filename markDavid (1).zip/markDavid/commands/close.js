const Discord = require('discord.js');

// -close
module.exports = {
    name: "close",
    execute: (message, args) => {

      if (!message.channel.name.includes(`ticket-`) && !message.channel.name.includes(`hr-`))  {

        return;
      }

      message.channel.delete();
      console.log(`User: (${message.author.username}) closed (${message.channel.name}).`);
    }
  }

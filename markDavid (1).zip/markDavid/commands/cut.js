const Discord = require('discord.js');
const config = require('../storage/config.json');
const bot = new Discord.Client();
const math = require('mathjs');

// -cut <#>
module.exports = {
    name: "cut",
    execute: (message, args) => {

      if(!args[0]) return message.channel.send(new Discord.RichEmbed().setDescription('**Usage** `-cut <#>`').setColor(config.color));

      if (isNaN(args[0])) return message.channel.send(new Discord.RichEmbed().setDescription('**Please provide a valid number**').setColor(config.color));

      let flv = math.divide(100, 88);

      let mmv = math.divide(100, 6);

      let srv = math.divide(100, 6);

      let cut = args[0];

      let flc = math.divide(cut, flv);

      let mmc = math.divide(cut, mmv);

      let src = math.divide(cut, srv);

      let embed = new Discord.RichEmbed()
      .setAuthor(`Athena Commission System`, config.logo)
      .addField(`**Cut - ${cut}**`, `**Freelancer's Cut = $${math.round(flc)}\nManagement's Cut = $${math.round(mmc)}\nSales Representative's Cut = $${math.round(src)}**`)
      .setColor(config.color);

      message.channel.send(embed);
      console.log(`User: (${message.author.username}) calculated a cut.`);
    }
  }

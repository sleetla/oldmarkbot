const Discord = require('discord.js');
const ms = require('ms');
const math = require('mathjs');
const rn = require('random-number');
const config = require('../storage/config.json');
let cooldown = new Set();

// -new
module.exports = {
  name: "new",
  execute: (message, args) => {

    var options = {
      min: 100002,
      max: 800002,
      integer: true
    }

    if (cooldown.has(message.author.id)) {
    message.channel.send(new Discord.RichEmbed().setColor("#FF9090").setDescription(`:x: **You can only open one ticket per 5 minutes.**`));
      return;
    }

    if (message.mentions.members.first()) {
      return;
    }

    if (args[0]) {
      message.channel.send(new Discord.RichEmbed().setColor(config.color).setDescription('**Usage** `-new`'));
      return;
    }

    if (!args[0]) {

      cooldown.add(message.author.id);

      setTimeout(function() {
        cooldown.delete(message.author.id)
      }, ms('5m'));


      let tcn = Math.floor(Math.random() + rn(options)) + 1; // Ticket Number

      message.guild.createChannel(`ticket-${tcn}`, 'text').then(c => {
        c.setParent('485272311830806528');
        c.overwritePermissions(c.guild.defaultRole, {
          VIEW_CHANNEL: false,
          SEND_MESSAGES: false
        })
        c.overwritePermissions(message.member, {
          VIEW_CHANNEL: true,
          SEND_MESSAGES: true
        })
        c.send(new Discord.RichEmbed().setTitle("Athena Commission System").setColor(config.color).setDescription(`Dear ${message.author},\n\nThank you for contacting Athena Services.\n\n:regional_indicator_a: to order automatically.\n:regional_indicator_b: to speak with a real person.\n:regional_indicator_c: to close your ticket.`).setFooter("© Athena Services", config.logo).setTimestamp())
        .then(async msg => {

          await msg.react('🇦')
          await msg.react('🇧')
          await msg.react('🇨')
        })
        message.channel.send(new Discord.RichEmbed().setDescription(`:white_check_mark: Your ticket has been created ${c}`).setColor(config.color));

        console.log(`User: (${message.author.username}) created a ticket.`);

        return;
      })
    }
  }
}
